import { RouterModule, ActivatedRoute  } from '@angular/router';
import { Component, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { HttpServiceService } from '../../../services/http-service.service';
import { FormsModule } from '@angular/forms';
import { WishlistAndCartService } from '../../../services/wishlist-service';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './header.html',
  styleUrls: ['./header.css']

})
export class Header {
get isLoggedIn(): boolean { return this.apiurl.isLoggedIn(); }
    constructor(  public apiurl: HttpServiceService, 
                  public cd: ChangeDetectorRef, 
                  private router: Router,
                  private route: ActivatedRoute,
                  public cartWishService: WishlistAndCartService  
               ) {{  this.imageURL = this.apiurl.imageBaseURL; }
              }


  isMenuOpen = false;
  imageURL: string;
  selectedCategory: string | null = null;
  isSearchOpen = false;
  searchQuery = '';
  wishlistCount: number = 0;
  cartCount: number = 0;



  ngOnInit() {

    this.route.queryParams.subscribe(params => { this.selectedCategory = params['gstyle'] || null;  });
    this.wishlistCount = this.cartWishService.wishlistCount;
    this.cartCount = this.cartWishService.cartCount;
    this.cd.detectChanges();


  }

toggleSearch() {
  this.isSearchOpen = !this.isSearchOpen;
}

searchProducts() {
  const query = this.searchQuery.trim();
  if (!query) {  return;  }
  console.log('Searching:', query);

  // Example:
  // this.router.navigate(['/products'], {
  //   queryParams: { search: query }
  // });
}

  clearSearch() {
    this.searchQuery = '';
  }


  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  openAccount() {
    // Mobile drawer agar open hai toh use close kar do
    if (this.isMenuOpen) {
      this.toggleMenu();
    }
    // Token check karke routing
    const token = localStorage.getItem('adminToken');
    console.log('profile button click:', token);
    this.router.navigate([token ? '/profile' : '/login']);
  }
  openWishList() {  this.router.navigate([ '/wishlist']); }
  openCart() { this.router.navigate([ '/my-cart']); }

  logout() {
  if (this.isMenuOpen) { this.toggleMenu(); }
  localStorage.removeItem('authToken'); // Token clear step
  this.router.navigate(['/login']);
  this.cd.detectChanges();
}
}