import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HttpServiceService } from '../../services/http-service.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-my-cart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-cart.html',
  styleUrls: ['./my-cart.css']
})
export class MyCart implements OnInit {
  cartItems: any[] = [];
  imageURL: string;
  loading = true;

  constructor(
    private api: HttpServiceService,
    private cd: ChangeDetectorRef,
    private router: Router,
    private toastr: ToastrService
  ) {
    this.imageURL = this.api.imageBaseURL;
  }
  get isLoggedIn(): boolean {  return this.api.isLoggedIn(); }


  ngOnInit() {
    this.isLoggedIn ? this.fetchCart() : this.fetchCartProducts();
  }

  fetchCart() {
    this.loading = true;
    this.api.get('users/cart').subscribe({
      next: (res: any) => {
        this.cartItems = res?.cart || res?.items || res || [];
        this.loading = false;
        this.cd.detectChanges();
      },
      error: (err) => {
        this.loading = false;
        this.toastr.error(err?.error?.message || 'Failed to load cart');
        this.cd.detectChanges();
      }
    });
  }
  fetchCartProducts() {
    const productIDS = localStorage.getItem('guest-cart');
    
    this.loading = true;
    this.api.post('products/get-by-ids', productIDS).subscribe({
      next: (res: any) => {
        console.log('product ids:', res);
        this.cartItems = res?.cart || res?.items || res || [];
        this.loading = false;
        this.cd.detectChanges();
      },
      error: (err) => {
        this.loading = false;
        this.toastr.error(err?.error?.message || 'Failed to load cart');
        this.cd.detectChanges();
      }
    });
  }

  removeItem(productId: string) {
    this.api.delete('users/cart', productId).subscribe({
      next: () => {
        this.toastr.success('Item removed from cart');
        this.cartItems = this.cartItems.filter(item => (item.product?._id || item._id || item.id) !== productId);
        this.cd.detectChanges();
      },
      error: (err) => {
        this.toastr.error(err?.error?.message || 'Could not remove item');
      }
    });
  }

  get subtotal(): number {
    return this.cartItems.reduce((acc, item) => {
      const price = item.selling_price || item.price || item.product?.selling_price || 0;
      const qty = item.quantity || 1;
      return acc + (price * qty);
    }, 0);
  }

  checkout() {
    this.toastr.info('Checkout functionality coming soon!');
  }
}