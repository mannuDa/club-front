import { Injectable } from '@angular/core';
import { Observable, forkJoin, of } from 'rxjs';
import { catchError, finalize, map } from 'rxjs/operators';
import { HttpServiceService } from './http-service.service';
import { ToastrService } from 'ngx-toastr';

interface CartOptions {
  size?: string;
  colour?: string;
  quantity?: number;
}

@Injectable({ providedIn: 'root' })
export class WishlistAndCartService {
  private busy = new Set<string>();

  // Guest (not logged in) cart lives only in localStorage under this key.
  private readonly GUEST_CART_KEY = 'guest-cart';
  private merging = false;

  wishlistIds: string[] = [];
  cartItems: any[] = [];

  constructor(
    private apiurl: HttpServiceService,
    private toast: ToastrService
  ) {    this.sync();  }

  get isLoggedIn(): boolean {  return this.apiurl.isLoggedIn(); }

  sync(): void {
    if (this.isLoggedIn) {
      this.loadWishlist();
      this.mergeGuestCart(); // pushes any guest items to the server, then loads the cart
    } else {
      this.clear();
    }
  }

  clear(): void {
    this.wishlistIds = [];
    this.cartItems = this.loadGuestCart(); // a guest still sees their local cart count
    this.busy.clear();
  }

  /* ---------------------------- helpers ---------------------------- */



  private requireLogin(action: string): boolean {
    if (this.isLoggedIn) return true;
    this.toast.error(`Please log in to ${action}.`);
    return false;
  }

  private errorMsg(err: any, fallback: string): string {
    return err?.error?.message || fallback;
  }

  /* ------------------------- guest cart (local) ------------------------- */

  private loadGuestCart(): any[] {
    try {
      const raw = localStorage.getItem(this.GUEST_CART_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  private saveGuestCart(items: any[] = this.cartItems): void {
    try {
      if (items.length) {
        localStorage.setItem(this.GUEST_CART_KEY, JSON.stringify(items));
      } else {
        localStorage.removeItem(this.GUEST_CART_KEY);
      }
    } catch {
      /* storage full or blocked: the in-memory cart still works for this session */
    }
  }

  // Add/remove without an API call. Same toggle behaviour as the logged-in cart.
  private toggleGuestCart(productId: string): void {
    const id = String(productId);

    if (this.checkCart(productId)) {
      this.cartItems = this.cartItems.filter(
        (item) => !(this.cartItemProductId(item) === id)
      );
      this.toast.success('Removed from your bag');
    } else {
      this.cartItems = [
        ...this.cartItems,
        { prodID: productId },
      ];
      this.toast.success('Added to your bag. Please log in to check out.');
    }

    this.saveGuestCart();
  }

  // After login: send guest items to the server cart, keep only the ones that failed, then reload.
  private mergeGuestCart(): void {
    if (this.merging) return;

    const guestItems = this.loadGuestCart();
    if (!guestItems.length) {
      this.loadCart();
      return;
    }

    this.merging = true;

    forkJoin(
      guestItems.map((item) =>
        this.apiurl
          .post('users/cart', {
            prodID: this.cartItemProductId(item),
            size: item.size ?? null,
            colour: item.colour ?? null,
            quantity: item.quantity ?? 1,
          })
          .pipe(
            map(() => null),
            catchError(() => of(item))
          )
      )
    )
      .pipe(finalize(() => (this.merging = false)))
      .subscribe((results: any[]) => {
        this.saveGuestCart(results.filter((r) => r !== null));
        this.loadCart();
      });
  }

  /* ---------------------------- wishlist ---------------------------- */

  loadWishlist(): Observable<any> {
    return this.apiurl.get('users/wishlist');
  }

  checkwishlist(productwishID: string): boolean {
    return this.wishlistIds.includes(productwishID);
  }

  toggleWishlist(product: any): void {
    if (!this.requireLogin('add items to your wish list')) return;

    const productId = product.id;
    const key = 'w' + productId;
    if (this.busy.has(key)) return;

    this.busy.add(key);
    const isAlreadyInWishlist = this.checkwishlist(productId);

    // Optimistic UI update
    if (isAlreadyInWishlist) {
      this.wishlistIds = this.wishlistIds.filter((id) => id !== productId);
    } else {
      this.wishlistIds = [...this.wishlistIds, productId];
    }

    // Condition ke hisaab se API call choose karna
    const apiCall$ = isAlreadyInWishlist
      ? this.apiurl.delete('users/wishlist', productId) // Remove (DELETE)
      : this.apiurl.post('users/wishlist', { prodID: productId }); // Add (POST)
    console.log('Wishlist API Call:', isAlreadyInWishlist ? 'DELETE' : 'POST', 'for productId:', productId);
    apiCall$
      .pipe(finalize(() => this.busy.delete(key)))
      .subscribe({
        next: () => {
          const msg = isAlreadyInWishlist ? 'Removed from your wish list' : 'Added to your wish list';
          this.toast.success(msg);
        },
        error: (err: any) => {
          // Error aane par state wapas rollback kar dena (revert)
          if (isAlreadyInWishlist) {
            this.wishlistIds = [...this.wishlistIds, productId];
          } else {
            this.wishlistIds = this.wishlistIds.filter((x) => x !== productId);
          }
          this.toast.error(this.errorMsg(err, 'Could not update your wish list'));
        },
      });
  }

  /* ------------------------------ cart ------------------------------ */

  get cartCount(): number {
    return this.cartItems.reduce((n, i) => n + (i.quantity || 0), 0);
  }
  get wishlistCount(): number {  return this.wishlistIds.length;  }

  // The cart response shape isn't guaranteed, so look in the usual places.
  // Returns null when no array is found, so callers can reload instead of wiping the cart.
  private extractCartItems(res: any): any[] | null {
    if (Array.isArray(res)) return res;
    const candidates: any[] = [
      res?.items,
      res?.cart?.items,
      res?.cart?.products,
      res?.products,
      res?.data?.items,
      res?.data?.cart?.items,
      res?.data,
    ];
    return candidates.find((c) => Array.isArray(c)) ?? null;
  }

  // Product id of one cart line, whether the product is populated (object) or just an id.
  private cartItemProductId(item: any): string {
    const ref =
      item?.prodID ?? item?.productId ?? item?.productID ?? item?.product_id ?? item?.product;
    const id = ref && typeof ref === 'object' ? (ref._id ?? ref.id) : ref;
    // Last resort: the line's own id (only if the backend flattens product fields onto the line)
    return String(id ?? item?._id ?? item?.id ?? '');
  }

  // Only compares size/colour when the caller actually passes them.
  private sameVariant(item: any, options: CartOptions): boolean {
    const matches = (actual: any, wanted?: string) =>
      wanted === undefined || wanted === null || String(actual ?? '') === String(wanted);
    return matches(item?.size, options.size) && matches(item?.colour, options.colour);
  }

  loadCart(): void {
    this.apiurl.get('users/cart').subscribe({
      next: (res: any) => {
        const items = this.extractCartItems(res);
        if (!items) { console.warn('[cart] Unexpected response shape from users/cart:', res); }
        this.cartItems = items ?? [];
      },
      error: (err: any) => console.error(err),
    });
  }

  checkCart(productId: string, options: CartOptions = {}): boolean {
    if (!Array.isArray(this.cartItems)) return false;
    const id = String(productId);
    return this.cartItems.some( 
      (item) => this.cartItemProductId(item) === id && this.sameVariant(item, options)
    );
  }

  toggleCartlist(product: any): void {
    const productId = product.id;
    if (!this.isLoggedIn) 
    {  this.toggleGuestCart(productId);
      return;
    }

    const key = 'c' + productId;
    if (this.busy.has(key)) return;

    this.busy.add(key);
    const isAlreadyInCart = this.checkCart(productId);
    let apiCall$: Observable<any>;
    let successMessage = '';

    if (isAlreadyInCart) {
      const params = new URLSearchParams();
      const qs = params.toString() ? `?${params.toString()}` : '';
      apiCall$ = this.apiurl.delete('users/cart', `${productId}${qs}`);
      successMessage = 'Removed from your bag';
    } else {
      const body = { prodID: productId };
      apiCall$ = this.apiurl.post('users/cart', body);
      successMessage = 'Added to your bag';
    }

    apiCall$
      .pipe(finalize(() => this.busy.delete(key)))
      .subscribe({
        next: (res: any) => {
          // Use the cart from the response if there is one; otherwise re-fetch it.
          // (Old code set the cart to [] after a remove, and left it unchanged after an add,
          // whenever the response had no `items`, so checkCart() kept returning the wrong answer.)
          const items = this.extractCartItems(res);
          if (items) {
            this.cartItems = items;
          } else {
            this.loadCart();
          }
          this.toast.success(successMessage);
        },
        error: (err: any) => {
          const errorMsgPrefix = isAlreadyInCart ? 'Could not update your bag' : 'Could not add to your bag';
          this.toast.error(this.errorMsg(err, errorMsgPrefix));
        },
      });
  }
}
