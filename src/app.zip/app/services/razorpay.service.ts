

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpServiceService } from './http-service.service';

declare var Razorpay: any;

export interface CheckoutItem {
  productId: string;
  size: string;
  quantity: number;
}

export interface ShippingAddress {
  fullName: string;
  email: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
}

@Injectable({ providedIn: 'root' })
export class RazorpayService {
  private scriptPromise?: Promise<boolean>;

  // Change these two to match the routes you set up for createOrderAndPayment and verifyPayment.
  private readonly CREATE_ORDER_URL = 'users/create-order-payment';
  private readonly VERIFY_URL = 'users/payment/verify';

  // Assumes HttpServiceService has post(url, body) next to get(url).
  constructor(private api: HttpServiceService) {}

  /** Loads checkout.js once and reuses it. */
  loadScript(): Promise<boolean> {
    if (typeof Razorpay !== 'undefined') return Promise.resolve(true);
    if (!this.scriptPromise) {
      this.scriptPromise = new Promise<boolean>((resolve) => {
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.onload = () => resolve(true);
        script.onerror = () => {
          this.scriptPromise = undefined; // allow a retry
          resolve(false);
        };
        document.body.appendChild(script);
      });
    }
    return this.scriptPromise;
  }

  createOrder(payload: { userId: string; items: CheckoutItem[]; shippingAddress: ShippingAddress }): Observable<any> {
    return this.api.post(this.CREATE_ORDER_URL, payload);
  }

  verifyPayment(payload: {
    razorpay_order_id: string;
    razorpay_payment_id: string;
    razorpay_signature: string;
  }): Observable<any> {
    return this.api.post(this.VERIFY_URL, payload);
  }

  open(options: any): any {
    const rzp = new Razorpay(options);
    return rzp;
  }
}
